package com.example.samplechatapplication

data class User(
    var nickname: String? = null,
    var profileUrl: Int = 0,
    var id: Int? = null
)

