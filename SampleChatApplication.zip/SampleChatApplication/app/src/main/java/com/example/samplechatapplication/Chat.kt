package com.example.samplechatapplication

data class Chat(var name: String?, var message: String?, var imagePath: Int)