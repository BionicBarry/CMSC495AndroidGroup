package com.example.samplechatapplication

class ContactPhone(var number: String, var type: String)
