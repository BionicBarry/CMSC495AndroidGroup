package com.example.samplechatapplication

class ContactEmail(var address: String, var type: String)
